import django_filters
from django import forms
from .models import Marche, Localisation, Axe

class MarcheReportingFilter(django_filters.FilterSet):
    # Recherche textuelle sur le numéro de marché
    num_marche = django_filters.CharFilter(
        lookup_expr='icontains', 
        label="N° Marché",
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 01/2024...'})
    )
     # ✅ NOUVEAU — Situation travaux
    situation_w = django_filters.CharFilter(
        field_name='avancements__situation_w',
        lookup_expr='exact',
        label="Situation travaux",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    # ✅ NOUVEAU — Financement
    financement = django_filters.CharFilter(
        lookup_expr='icontains',
        label="Financement",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    
    # Filtre par Région (via la relation Axe -> Localisation)
    region = django_filters.ChoiceFilter(
        field_name='axe__pk_debut_district__region',
        choices=Localisation.REGION_CHOICES,
        label="Région",
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    # Filtre par Axe
    axe = django_filters.ModelChoiceFilter(
        queryset=Axe.objects.all(),
        label="Axe Routier",
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta:
        model = Marche
        fields = ['num_marche', 'region', 'axe', 'financement', 'type_travaux']