from django.urls import path
from .views import CustomAuthToken # La vue qui gère la connexion
from . import views

urlpatterns = [
    path('login/', CustomAuthToken.as_view(), name='api_login'),
    path('reporting/', views.reporting_view, name='marche_reporting'),
]