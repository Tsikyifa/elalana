from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from .serializers import MarcheListSerializer
from rest_framework import viewsets
from .models import Marche
from rest_framework.permissions import IsAuthenticated
from .filters import MarcheReportingFilter
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.db.models import Avg, Sum, Count

class CustomAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({'token': token.key, 'user_id': user.pk, 'email': user.email})
    
class MarcheStatusViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = MarcheListSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        # Tri par désignation de l'axe
        queryset = Marche.objects.all().order_by('axe__designation')
        
        if user.is_superuser:
            return queryset
        # Filtrer par l'attaché de suivi défini dans le modèle Axe
        return queryset.filter(axe__attache_suivi=user)
 
@login_required
def reporting_view(request):

    queryset = Marche.objects.select_related(
        'axe',
        'axe__pk_debut_district'
    ).prefetch_related(
        'avancements',
        'axe__segments_districts__district'
    ).order_by('axe__designation')

    f = MarcheReportingFilter(request.GET, queryset=queryset)

    marches = f.qs.distinct()

    # ✅ STATISTIQUES
    total_marches = marches.count()

    avg_physique = marches.aggregate(
        Avg('avancements__avancement_physique')
    )['avancements__avancement_physique__avg'] or 0

    total_financement = marches.aggregate(
        Sum('montant')
    )['montant__sum'] or 0

    context = {
        'filter': f,
        'marches': marches,
        'view_type': request.GET.get('view_type', 'axe'),
        'total_marches': total_marches,
        'avg_physique': round(avg_physique, 2),
        'total_financement': total_financement
    }

    return render(request, 'reporting/marche_report.html', context)