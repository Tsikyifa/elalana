from django.contrib import admin
from django.utils.html import format_html
from django.db import models
from .models import Axe, PKDistrict, Marche, PKMarche, Avancement, MediaAvancement, Localisation

from import_export import resources, fields
from import_export.widgets import ForeignKeyWidget, DateWidget, DecimalWidget

from import_export.admin import ImportExportModelAdmin

from django.contrib.auth.models import User


# Vérification pour le groupe OperateurTravaux
def is_operateur_travaux(user):
    return user.groups.filter(name='OperateurTravaux').exists()

# Chef d'axe
def is_chef_axe(user):
    return user.groups.filter(name='chef_axe').exists()

class LocalisationResource(resources.ModelResource):
    class Meta:
        model = Localisation
        # Vous pouvez choisir l'ordre des colonnes pour l'export
        fields = ('id', 'province', 'region', 'district')
        export_order = ('id', 'province', 'region', 'district')

@admin.register(Localisation)
class LocalisationAdmin(ImportExportModelAdmin): # Une seule classe qui hérite de ImportExport
    resource_class = LocalisationResource
    
    # On regroupe toutes les options ici
    list_display = ('district', 'region', 'province')
    list_filter = ('province', 'region')
    search_fields = ('district', 'region', 'province')
    
    # Cette ligne est cruciale pour que l'autocomplétion fonctionne 
    # dans AxeAdmin et PKDistrictInline
    ordering = ('province', 'region', 'district')


class PKDistrictInline(admin.TabularInline):
    model = PKDistrict
    extra = 1
    # Permet de saisir le nom du district directement dans le tableau
    autocomplete_fields = ['district'] 
    
    # Optionnel : pour rendre l'interface plus compacte
    fields = ('district', 'pk_debut', 'pk_fin')

class PKMarcheInline(admin.TabularInline):
    model = PKMarche
    extra = 1

class MediaAvancementInline(admin.TabularInline):
    model = MediaAvancement
    extra = 1
    readonly_fields = ('aperçu',)

    def aperçu(self, obj):
        if obj.fichier:
            return format_html('<img src="{}" style="width: 100px; height: auto;" />', obj.fichier.url)
        return "Pas d'aperçu"


class AxeResource(resources.ModelResource):
    # Changement : on utilise 'id' au lieu de 'district' pour mapper les IDs numériques
    pk_debut_district = fields.Field(
        column_name='pk_debut_district',
        attribute='pk_debut_district',
        widget=ForeignKeyWidget(Localisation, 'id') # Lie l'ID 19, 58, 64, etc.
    )
    pk_fin_district = fields.Field(
        column_name='pk_fin_district',
        attribute='pk_fin_district',
        widget=ForeignKeyWidget(Localisation, 'id')
    )
    
    attache_suivi = fields.Field(
        column_name='attache_suivi',
        attribute='attache_suivi',
        widget=ForeignKeyWidget(User, 'username')
    )

    class Meta:
        model = Axe
        # IMPORTANT : On définit l'id comme champ pivot pour les mises à jour
        import_id_fields = ('id',) 
        fields = (
            'id', 'designation', 'type_axe', 'longueur_total', 
            'pk_debut_district', 'pk_fin_district', 'description', 'attache_suivi'
        )
        export_order = fields

    def before_import_row(self, row, **kwargs):
        """
        Nettoyage automatique : si Excel contient "19 (TANA I)", 
        on ne garde que "19" pour que le ForeignKeyWidget fonctionne.
        """
        for field in ['pk_debut_district', 'pk_fin_district']:
            value = str(row.get(field, ''))
            if '(' in value:
                # On extrait uniquement les chiffres avant la parenthèse
                row[field] = value.split('(')[0].strip()

# --- ADMIN CLASSES ---
@admin.register(Axe)
class AxeAdmin(ImportExportModelAdmin): # Changement ici
    resource_class = AxeResource # Ajout ici
    list_display = ('designation', 'type_axe', 'longueur_total', 'pk_debut_district', 'pk_fin_district', 'attache_suivi')
    autocomplete_fields = ['pk_debut_district', 'pk_fin_district']
    list_filter = ('type_axe', 'attache_suivi', 'pk_debut_district__province')
    search_fields = ('designation', 'description', 'pk_debut_district__district', 'pk_fin_district__district')
    readonly_fields = ('updated_at',) # On complétera dynamiquement cette liste
    inlines = [PKDistrictInline]
    
    fieldsets = (
        ('Informations Générales', {
            'fields': ('designation', 'type_axe', 'description')
        }),
        ('Détails Géographiques', {
            'description': "Sélectionnez le district en saisissant son nom",
            'fields': ('pk_debut_district', 'pk_fin_district', 'longueur_total')
        }),
        ('Responsabilité', {
            'fields': ('attache_suivi', 'updated_at')
        }),
    )

    def get_readonly_fields(self, request, obj=None):
        """Rend le champ attache_suivi modifiable uniquement par les admins"""
        if request.user.is_superuser:
            return self.readonly_fields
        return list(self.readonly_fields) + ['attache_suivi']

    def save_model(self, request, obj, form, change):
        """Assigne automatiquement l'utilisateur connecté à la création"""
        if not obj.pk: # Si c'est une création (pas d'ID encore)
            if not request.user.is_superuser or not obj.attache_suivi:
                obj.attache_suivi = request.user
        super().save_model(request, obj, form, change)

    
    def get_queryset(self, request):
        qs = super().get_queryset(request).select_related(
            'pk_debut_district',
            'pk_fin_district'
        )

        if request.user.is_superuser or is_operateur_travaux(request.user):
            return qs

        if is_chef_axe(request.user):
            return qs.filter(attache_suivi=request.user)

        return qs.none()  # sécurité maximale



class MarcheResource(resources.ModelResource):
    # Liaison avec l'Axe par son nom (ex: RNP 2)
    axe = fields.Field(
        column_name='axe',
        attribute='axe',
        widget=ForeignKeyWidget(Axe, 'designation')
    )

    # Date formatée pour Excel (JJ/MM/AAAA)
    os_com = fields.Field(
        column_name='os_com',
        attribute='os_com',
        widget=DateWidget(format='%d/%m/%Y')
    )

    class Meta:
        model = Marche
        # L'id UUID est généré par Django si la colonne est vide dans le fichier
        import_id_fields = ('id',)
        fields = (
            'id', 'num_marche', 'axe', 'type_travaux', 'categorie_oeuvre', 
            'description', 'resume', 'financement', 'detail_financement', 
            'tiers', 'montant', 'titulaire', 'os_com', 'delai_unit', 'delai_nombre'
        )
        export_order = fields

    def before_import_row(self, row, **kwargs):
        """
        Optionnel : Cette fonction permet de convertir les labels en clés techniques
        si votre fichier Excel contient les noms complets (ex: "Gros Œuvre" -> "GROS")
        """
        # Mapping pour Categorie Oeuvre
        cat_map = {'Gros Œuvre': 'GROS', 'Petit Œuvre': 'PETIT'}
        if row.get('categorie_oeuvre') in cat_map:
            row['categorie_oeuvre'] = cat_map[row['categorie_oeuvre']]
            
        # Mapping pour Financement
        fin_map = {'Financement Extérieur': 'FIN_EX', 'FER': 'FER', 'RPI': 'RPI'}
        if row.get('financement') in fin_map:
            row['financement'] = fin_map[row['financement']]

@admin.register(Marche)
class MarcheAdmin(ImportExportModelAdmin):
    # 1. Configuration de l'affichage en liste (Dashboard enrichi)
    resource_class = MarcheResource # Ajout ici
    inlines=[PKMarcheInline]
    list_display = (
        'marche_identifiant', 
        'axe', 
        'resume_court',              # Résumé (tronqué si trop long)
        'get_itineraire_districts',  # Itinéraire ordonné par PK
        'financement_display',       # Type de financement (Badge)
        'avancement_physique_recap', # % physique avec couleur
        'situation_actuelle',        # Statut du chantier
    )
    autocomplete_fields = ['axe',]
    # 2. Filtres et Recherche
    list_filter = (
        'financement', 
        'type_travaux', 
        'axe',
        'categorie_oeuvre'
    )
    search_fields = ('num_marche', 'titulaire', 'axe__designation', 'resume', 'description')
    ordering = ('-os_com',)

    # 3. Optimisation des requêtes SQL
    def get_queryset(self, request):
        qs = super().get_queryset(request).select_related('axe')

        qs = qs.prefetch_related(
            models.Prefetch(
                'axe__segments_districts',
                queryset=PKDistrict.objects.order_by('pk_debut').select_related('district')
            ),
            'avancements'
        )

        if request.user.is_superuser or is_operateur_travaux(request.user):
            return qs

        if is_chef_axe(request.user):
            return qs.filter(axe__attache_suivi=request.user)

        return qs.none()


    # --- MÉTHODES D'AFFICHAGE PERSONNALISÉES ---

    def resume_court(self, obj):
        """Affiche le début du résumé pour ne pas encombrer le tableau"""
        if obj.resume and len(obj.resume) > 50:
            return f"{obj.resume[:50]}..."
        return obj.resume
    resume_court.short_description = "Résumé du Marché"

    def financement_display(self, obj):
        """Affiche le financement avec un style distinctif"""
        colors = {
            'RPI': '#34495e',
            'FIN_EX': '#8e44ad',
            'FER': '#2980b9',
            'AUTRE': '#7f8c8d'
        }
        color = colors.get(obj.financement, '#7f8c8d')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.85em;">{}</span>',
            color,
            obj.get_financement_display()
        )
    financement_display.short_description = "Financement"

    def get_itineraire_districts(self, obj):
        """Affiche les districts traversés par l'axe, ordonnés par PK"""
        segments = obj.axe.segments_districts.all()
        noms_districts = [s.district.district for s in segments if s.district]
        
        if noms_districts:
            # District A -> District B
            return format_html(" <span style='color: #999;'>&rarr;</span> ".join(noms_districts))
        return format_html("<i style='color: #ccc;'>Non défini</i>")
    get_itineraire_districts.short_description = "Itinéraire"

    def avancement_physique_recap(self, obj):
        """Dernier % physique avec couleur d'alerte"""
        dernier = obj.avancements.first()
        if dernier and dernier.avancement_physique is not None:
            val = dernier.avancement_physique
            if val >= 80: color = "#27ae60"    # Vert
            elif val >= 40: color = "#f39c12"  # Orange
            else: color = "#e74c3c"            # Rouge
            return format_html('<b style="color: {};">{}%</b>', color, val)
        return "0%"
    avancement_physique_recap.short_description = "% Phys."

    def situation_actuelle(self, obj):
        """Affiche le dernier statut"""
        dernier = obj.avancements.first()
        return dernier.get_situation_w_display() if dernier else "Non démarré"
    situation_actuelle.short_description = "Statut"

    # --- SÉCURITÉ ---
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "axe":
            # Si admin ou opérateur, on montre tous les axes
            if request.user.is_superuser or is_operateur_travaux(request.user):
                kwargs["queryset"] = Axe.objects.all()
            elif is_chef_axe(request.user):
                kwargs["queryset"] = Axe.objects.filter(attache_suivi=request.user)
            else:
                kwargs["queryset"] = Axe.objects.none()
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

    def marche_identifiant(self, obj):
        """Affiche le numéro et la désignation sur la même ligne"""
        # On met le numéro en gras pour bien le distinguer
        return format_html(
            '<b>{}</b> - <span style="color: #666;">{}</span>',
            obj.num_marche,
            obj.description # Ou obj.designation selon le nom de votre champ
        )
    marche_identifiant.short_description = "Référence & Marché"


class AvancementResource(resources.ModelResource):
    # Liaison avec le Marché via son numéro (num_marche)
    marche = fields.Field(
        column_name='num_marche',
        attribute='marche',
        widget=ForeignKeyWidget(Marche, 'num_marche')
    )

    # Date de l'avancement (Format JJ/MM/AAAA dans Excel)
    date_avancement = fields.Field(
        column_name='date_avancement',
        attribute='date_avancement',
        widget=DateWidget(format='%d/%m/%Y')
    )

    # Configuration des champs décimaux pour éviter l'erreur ConversionSyntax
    avancement_physique = fields.Field(
        column_name='avancement_physique',
        attribute='avancement_physique',
        widget=DecimalWidget()
    )

    avancement_financier = fields.Field(
        column_name='avancement_financier',
        attribute='avancement_financier',
        widget=DecimalWidget()
    )

    class Meta:
        model = Avancement
        # On identifie une ligne par le marché ET la date pour permettre les mises à jour
        import_id_fields = ('marche', 'date_avancement')
        
        fields = (
            'id', 'marche', 'date_avancement', 'avancement_physique', 
            'avancement_financier', 'situation_w', 'detail_situation', 'observation'
        )
        # Ordre des colonnes dans le fichier Excel exporté
        export_order = fields

    def before_import_row(self, row, **kwargs):
        """
        Nettoyage des données Excel avant importation
        """
        # 1. Nettoyage des pourcentages (enlève %, espaces, et remplace virgule par point)
        for field in ['avancement_physique', 'avancement_financier']:
            val = row.get(field)
            if val:
                clean_val = str(val).replace('%', '').replace(',', '.').strip()
                row[field] = clean_val if clean_val else None

        # 2. Gestion de la situation (si l'utilisateur écrit 'En cours' au lieu de 'EN_COURS')
        situation = row.get('situation_w')
        if situation:
            sit_map = {
                "Phase d'étude": "ETUDE",
                "Passation de marché": "PASSATION",
                "En cours": "EN_COURS",
                "Achéve": "ACHEVE",
                "Achevé": "ACHEVE",
                "Résilié": "RESILIE"
            }
            # Si le texte correspond à un label, on le convertit en clé technique
            if situation in sit_map:
                row['situation_w'] = sit_map[situation]
            else:
                # Sinon on force en majuscule pour correspondre aux clés techniques
                row['situation_w'] = str(situation).upper().replace(' ', '_')

@admin.register(Avancement)
class AvancementAdmin(ImportExportModelAdmin):
    # 1. Configuration de l'affichage en liste (Dashboard enrichi)
    resource_class = AvancementResource # Ajout ici
    # Ajout de 'avancement_anterieur' dans la liste
    list_display = (
        'marche', 
        'date_avancement', 
        'situation_w', 
        'avancement_anterieur', # Nouvelle colonne
        'avancement_physique_display', 
        'avancement_financier_display', 
        'get_temporel'
    )
    
    list_filter = ('situation_w', 'date_avancement', 'marche__axe')
    search_fields = ('marche__num_marche', 'marche__titulaire', 'observation')
    readonly_fields = ('get_temporel',)
    autocomplete_fields = ['marche'] 
    inlines = [MediaAvancementInline]

    fieldsets = (
        ('Référence', {'fields': ('marche', 'date_avancement')}),
        ('État des Lieux', {'fields': ('situation_w', 'detail_situation')}),
        ('Indicateurs (%)', {'fields': (('avancement_physique', 'avancement_financier'), 'get_temporel')}),
        ('Commentaires', {'fields': ('observation',)}),
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request).select_related(
            'marche',
            'marche__axe'
        )

        if request.user.is_superuser or is_operateur_travaux(request.user):
            base_qs = qs
        elif is_chef_axe(request.user):
            base_qs = qs.filter(marche__axe__attache_suivi=request.user)
        else:
            return qs.none()

        latest_ids = (
            base_qs.order_by('marche', '-date_avancement', '-id')
            .distinct('marche')
            .values_list('id', flat=True)
        )

        return base_qs.filter(id__in=latest_ids)


    # --- MÉTHODES D'AFFICHAGE ---

    def avancement_anterieur(self, obj):
        """
        Récupère l'avancement physique qui précède immédiatement l'actuel 
        pour ce marché spécifique.
        """
        anterieur = Avancement.objects.filter(
            marche=obj.marche,
            date_avancement__lt=obj.date_avancement
        ).order_by('-date_avancement').first()
        
        if anterieur and anterieur.avancement_physique is not None:
            return f"{anterieur.avancement_physique}%"
        return format_html('<span style="color: #999;">-</span>')
    
    avancement_anterieur.short_description = "Phys. Antérieur"

    def get_temporel(self, obj):
        return f"{obj.avancement_temporel}%"
    get_temporel.short_description = "Consommation Délais"

    def avancement_physique_display(self, obj):
        return f"{obj.avancement_physique}%" if obj.avancement_physique is not None else "-"
    avancement_physique_display.short_description = "Physique Actuel"

    def avancement_financier_display(self, obj):
        return f"{obj.avancement_financier}%" if obj.avancement_financier is not None else "-"
    avancement_financier_display.short_description = "Financier"

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "marche":
            if request.user.is_superuser or is_operateur_travaux(request.user):
                kwargs["queryset"] = Marche.objects.all()
            else:
                kwargs["queryset"] = Marche.objects.filter(axe__attache_suivi=request.user)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    

