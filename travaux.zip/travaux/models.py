from django.db import models
import uuid
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import date
from django.core.validators import MaxValueValidator, MinValueValidator
#
from django.core.exceptions import ValidationError  # 🔹 si pas déjà importé

class Localisation(models.Model):

    PROVINCE_CHOICES = [
        ('ANTANANARIVO', 'Antananarivo'),
        ('ANTSIRANANA', 'Antsiranana'),
        ('FIANARANTSOA', 'Fianarantsoa'),
        ('MAHAJANGA', 'Mahajanga'),
        ('TOAMASINA', 'Toamasina'),
        ('TOLIARA', 'Toliara'),
    ]

    REGION_CHOICES = [
        ('ANALAMANGA', 'Analamanga'), ('VAKINANKARATRA', 'Vakinankaratra'),
        ('ITASY', 'Itasy'), ('BONGOLAVA', 'Bongolava'),
        ('SAVA', 'Sava'), ('DIANA', 'Diana'),
        ('MATSIATRA_AMBONY', 'Matsiatra Ambony'),
        ('AMORON_I_MANIA', 'Amoron\'i Mania'),
        ('VATOVAVY', 'Vatovavy'),
        ('FITOVINANY', 'Fitovinany'),
        ('IHOROMBE', 'Ihorombe'),
        ('ATSIMO_ATSINANANA', 'Atsimo-Atsinanana'),
        ('BOENY', 'Boeny'),
        ('SOFIA', 'Sofia'),
        ('BETSIBOKA', 'Betsiboka'),
        ('MELAKY', 'Melaky'),
        ('ATSINANANA', 'Atsinanana'),
        ('ALAOTRA_MANGORO', 'Alaotra-Mangoro'),
        ('ANALANJIROFO', 'Analanjirofo'),
        ('ATSIMO_ANDREFANA', 'Atsimo-Andrefana'),
        ('ANDROY', 'Androy'),
        ('ANOSY', 'Anosy'),
        ('MENABE', 'Menabe'),
    ]

    province = models.CharField(max_length=20, choices=PROVINCE_CHOICES)
    region = models.CharField(max_length=30, choices=REGION_CHOICES)
    district = models.CharField(max_length=100)

    class Meta:
        verbose_name = "Localisation (District)"
        verbose_name_plural = "Localisations"
        ordering = ['province', 'region', 'district']

        # 🔹 MODIFICATION (remplace unique_together)
        constraints = [
            models.UniqueConstraint(
                fields=['district', 'region'],
                name='unique_district_region'
            )
        ]

    def __str__(self):
        return f"{self.district} ({self.region})"

class Axe(models.Model):

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    TYPE_AXE = [
        ('RN', 'Route Nationale'),
        ('RR', 'Route Régionale'),
        ('RC', 'Route Communale'),
        ('AU', 'Autre'),
    ]

    designation = models.CharField(max_length=255)
    type_axe = models.CharField(max_length=2, choices=TYPE_AXE, default='AU')
    longueur_total = models.DecimalField(max_digits=10, decimal_places=3, default=0)

    pk_debut_district = models.ForeignKey(
        Localisation,
        on_delete=models.PROTECT,
        related_name='axes_depart',
        null=True
    )

    pk_fin_district = models.ForeignKey(
        Localisation,
        on_delete=models.PROTECT,
        related_name='axes_fin',
        null=True
    )

    description = models.TextField(blank=True, null=True)
    attache_suivi = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.designation} ({self.get_type_axe_display()})"


class PKDistrict(models.Model):

    axe = models.ForeignKey('Axe', on_delete=models.CASCADE, related_name='segments_districts')

    district = models.ForeignKey(
        Localisation,
        on_delete=models.PROTECT,
        related_name='segments_traverses',
        null=True
    )

    pk_debut = models.DecimalField(max_digits=10, decimal_places=3)
    pk_fin = models.DecimalField(max_digits=10, decimal_places=3)

    # 🔹 AJOUT VALIDATION
    def clean(self):
        if self.pk_debut >= self.pk_fin:
            raise ValidationError("Le PK début doit être inférieur au PK fin.")

        segments = PKDistrict.objects.filter(
            axe=self.axe
        ).exclude(id=self.id)

        for segment in segments:
            if not (self.pk_fin <= segment.pk_debut or self.pk_debut >= segment.pk_fin):
                raise ValidationError("Ce segment chevauche un autre segment existant.")

    class Meta:
        ordering = ['axe', 'pk_debut']

        # 🔹 MODIFICATION
        constraints = [
            models.UniqueConstraint(
                fields=['axe', 'pk_debut'],
                name='unique_pk_debut_par_axe'
            )
        ]

    def __str__(self):
        return f"{self.axe.designation} - {self.district} ({self.pk_debut} → {self.pk_fin})"



class Marche(models.Model):

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    num_marche = models.CharField(max_length=255)
    axe = models.ForeignKey('Axe', on_delete=models.CASCADE, related_name='marches')

    type_travaux = models.CharField(max_length=50)
    categorie_oeuvre = models.CharField(max_length=10)

    description = models.TextField()
    resume = models.CharField(max_length=255)
    # Définissez les options possibles
    FINANCEMENT_CHOICES = [
        ('RPI', 'RPI'),
        ('FIN_EX', 'Financement Extérieur'),
        ('FER', 'FER'),
        ('AUTRE', 'Autre'),
    ]

    financement = models.CharField(
        max_length=10, 
        choices=FINANCEMENT_CHOICES
    )
    detail_financement = models.CharField(max_length=255, blank=True, null=True)

    tiers = models.CharField(max_length=100)
    montant = models.DecimalField(max_digits=20, decimal_places=2, blank=True, null=True)
    titulaire = models.CharField(max_length=255)

    os_com = models.DateField(blank=True, null=True)
    delai_unit = models.CharField(max_length=10)
    delai_nombre = models.IntegerField(blank=True, null=True)

    # ============================
    # 🔹 AJOUT 1 : Date fin prévue
    # ============================
    @property
    def date_fin_prevue(self):
        if not self.os_com or not self.delai_nombre:
            return None

        jours = self.delai_nombre
        if self.delai_unit == 'MOIS':
            jours *= 30
        elif self.delai_unit == 'SEMAINE':
            jours *= 7

        return self.os_com + timezone.timedelta(days=jours)

    # ============================
    # 🔹 AJOUT 2 : Districts touchés
    # ============================
    @property
    def districts_touches(self):
        """
        Déduit automatiquement les districts impactés
        en croisant PKMarche et PKDistrict.
        """

        districts = set()

        for seg_m in self.segments_pk.all():

            overlapping = self.axe.segments_districts.filter(
                pk_debut__lt=seg_m.pk_fin,
                pk_fin__gt=seg_m.pk_debut
            )

            for seg_d in overlapping:
                districts.add(seg_d.district)

        return districts

    # ============================
    # 🔹 AJOUT 3 (OPTIONNEL) : Régions touchées
    # ============================
    @property
    def regions_touchees(self):
        return set(d.region for d in self.districts_touches)

    # ============================
    # 🔹 AJOUT 4 (OPTIONNEL) : Longueur totale du marché
    # ============================
    @property
    def longueur_totale(self):
        total = 0
        for seg in self.segments_pk.all():
            total += float(seg.pk_fin - seg.pk_debut)
        return round(total, 3)

    def __str__(self):
        return f"{self.num_marche} - {self.axe.designation}"


class PKMarche(models.Model):

    marche = models.ForeignKey(
        'Marche',
        on_delete=models.CASCADE,
        related_name='segments_pk',
        verbose_name="Marché"
    )

    pk_debut = models.DecimalField(
        max_digits=10,
        decimal_places=3,
        verbose_name="PK Début"
    )

    pk_fin = models.DecimalField(
        max_digits=10,
        decimal_places=3,
        verbose_name="PK Fin"
    )

    description = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name="Description du tronçon"
    )

    # 🔹 AJOUT : validation métier
    def clean(self):
        super().clean()

        # 🔹 Vérification logique PK début < PK fin
        if self.pk_debut >= self.pk_fin:
            raise ValidationError("Le PK début doit être strictement inférieur au PK fin.")

        # 🔹 Vérification chevauchement
        segments = PKMarche.objects.filter(
            marche=self.marche
        ).exclude(id=self.id)

        for segment in segments:
            if not (self.pk_fin <= segment.pk_debut or self.pk_debut >= segment.pk_fin):
                raise ValidationError(
                    f"Ce segment chevauche un segment existant : "
                    f"PK {segment.pk_debut} → {segment.pk_fin}"
                )

    class Meta:
        verbose_name = "PK du Marché"
        verbose_name_plural = "PK des Marchés"

        ordering = ['marche', 'pk_debut']

        # 🔹 MODIFICATION : remplace ancienne logique implicite
        constraints = [
            models.UniqueConstraint(
                fields=['marche', 'pk_debut'],
                name='unique_pk_debut_par_marche'
            )
        ]

    def __str__(self):
        return f"{self.marche.num_marche} : PK {self.pk_debut} → {self.pk_fin}"




class Avancement(models.Model):

    marche = models.ForeignKey(
        'Marche',
        on_delete=models.CASCADE,
        related_name='avancements'
    )

    date_avancement = models.DateField()

    avancement_physique = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        null=True,
        blank=True
    )

    avancement_financier = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        null=True,
        blank=True
    )

    situation_w = models.CharField(max_length=20)
    detail_situation = models.TextField(blank=True, null=True)
    observation = models.TextField(blank=True, null=True)

    # 🔹 CORRECTION SECURITE
    @property
    def avancement_temporel(self):

        if self.situation_w == 'ACHEVE':
            return 100.0

        os_date = self.marche.os_com
        nb_delai = self.marche.delai_nombre
        unite = self.marche.delai_unit

        if not os_date or not nb_delai:
            return 0.0

        jours_totaux = nb_delai
        if unite == 'MOIS':
            jours_totaux *= 30
        elif unite == 'SEMAINE':
            jours_totaux *= 7

        jours_passes = (self.date_avancement - os_date).days

        if jours_passes <= 0:
            return 0.0

        pourcentage = (jours_passes / jours_totaux) * 100
        return round(min(pourcentage, 100.0), 2)

    # 🔹 AJOUT indicateur retard
    @property
    def est_en_retard(self):
        if self.avancement_temporel > (self.avancement_physique or 0):
            return True
        return False

    class Meta:
        ordering = ['-date_avancement']

        # 🔹 AJOUT index performance
        indexes = [
            models.Index(fields=['date_avancement']),
        ]

    def __str__(self):
        return f"Avancement {self.marche.num_marche} au {self.date_avancement}"

    

class MediaAvancement(models.Model):

    avancement = models.ForeignKey(
        'Avancement',
        on_delete=models.CASCADE,
        related_name='medias'
    )

    fichier = models.FileField(
        upload_to='travaux/%Y/%m/%d/'
    )

    legende = models.CharField(max_length=255, blank=True)
    date_upload = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Média pour {self.avancement}"
