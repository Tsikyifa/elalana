# reporting/templatetags/pk_utils.py
from django import template

register = template.Library()

@register.filter
def format_pk(value):
    try:
        val = float(value)
        entiere = int(val)
        # On calcule les mètres (partie décimale)
        metres = int(round((val - entiere) * 1000))
        return f"{entiere:03d}+{metres:03d}"
    except (ValueError, TypeError):
        return value